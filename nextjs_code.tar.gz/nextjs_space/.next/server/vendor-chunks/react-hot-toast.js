"use strict";
exports.id = "vendor-chunks/react-hot-toast";
exports.ids = ["vendor-chunks/react-hot-toast"];
exports.modules = {

/***/ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/react-hot-toast/dist/index.mjs":
/*!*******************************************************************************************!*\
  !*** ../../../../opt/hostedapp/node/root/app/node_modules/react-hot-toast/dist/index.mjs ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CheckmarkIcon: () => (/* binding */ w),
/* harmony export */   ErrorIcon: () => (/* binding */ _),
/* harmony export */   LoaderIcon: () => (/* binding */ V),
/* harmony export */   ToastBar: () => (/* binding */ F),
/* harmony export */   ToastIcon: () => (/* binding */ M),
/* harmony export */   Toaster: () => (/* binding */ Ie),
/* harmony export */   "default": () => (/* binding */ _t),
/* harmony export */   resolveValue: () => (/* binding */ T),
/* harmony export */   toast: () => (/* binding */ n),
/* harmony export */   useToaster: () => (/* binding */ D),
/* harmony export */   useToasterStore: () => (/* binding */ I)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js");
/* harmony import */ var goober__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! goober */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/goober/dist/goober.modern.js");
/* __next_internal_client_entry_do_not_use__ CheckmarkIcon,ErrorIcon,LoaderIcon,ToastBar,ToastIcon,Toaster,default,resolveValue,toast,useToaster,useToasterStore auto */ var W = (e)=>typeof e == "function", T = (e, t)=>W(e) ? e(t) : e;
var U = (()=>{
    let e = 0;
    return ()=>(++e).toString();
})(), b = (()=>{
    let e;
    return ()=>{
        if (e === void 0 && "undefined" < "u") {}
        return e;
    };
})();

var Q = 20;
var S = new Map, X = 1e3, $ = (e)=>{
    if (S.has(e)) return;
    let t = setTimeout(()=>{
        S.delete(e), u({
            type: 4,
            toastId: e
        });
    }, X);
    S.set(e, t);
}, J = (e)=>{
    let t = S.get(e);
    t && clearTimeout(t);
}, v = (e, t)=>{
    switch(t.type){
        case 0:
            return {
                ...e,
                toasts: [
                    t.toast,
                    ...e.toasts
                ].slice(0, Q)
            };
        case 1:
            return t.toast.id && J(t.toast.id), {
                ...e,
                toasts: e.toasts.map((r)=>r.id === t.toast.id ? {
                        ...r,
                        ...t.toast
                    } : r)
            };
        case 2:
            let { toast: o } = t;
            return e.toasts.find((r)=>r.id === o.id) ? v(e, {
                type: 1,
                toast: o
            }) : v(e, {
                type: 0,
                toast: o
            });
        case 3:
            let { toastId: s } = t;
            return s ? $(s) : e.toasts.forEach((r)=>{
                $(r.id);
            }), {
                ...e,
                toasts: e.toasts.map((r)=>r.id === s || s === void 0 ? {
                        ...r,
                        visible: !1
                    } : r)
            };
        case 4:
            return t.toastId === void 0 ? {
                ...e,
                toasts: []
            } : {
                ...e,
                toasts: e.toasts.filter((r)=>r.id !== t.toastId)
            };
        case 5:
            return {
                ...e,
                pausedAt: t.time
            };
        case 6:
            let a = t.time - (e.pausedAt || 0);
            return {
                ...e,
                pausedAt: void 0,
                toasts: e.toasts.map((r)=>({
                        ...r,
                        pauseDuration: r.pauseDuration + a
                    }))
            };
    }
}, A = [], P = {
    toasts: [],
    pausedAt: void 0
}, u = (e)=>{
    P = v(P, e), A.forEach((t)=>{
        t(P);
    });
}, Y = {
    blank: 4e3,
    error: 4e3,
    success: 2e3,
    loading: 1 / 0,
    custom: 4e3
}, I = (e = {})=>{
    let [t, o] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(P);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>(A.push(o), ()=>{
            let a = A.indexOf(o);
            a > -1 && A.splice(a, 1);
        }), [
        t
    ]);
    let s = t.toasts.map((a)=>{
        var r, c;
        return {
            ...e,
            ...e[a.type],
            ...a,
            duration: a.duration || ((r = e[a.type]) == null ? void 0 : r.duration) || (e == null ? void 0 : e.duration) || Y[a.type],
            style: {
                ...e.style,
                ...(c = e[a.type]) == null ? void 0 : c.style,
                ...a.style
            }
        };
    });
    return {
        ...t,
        toasts: s
    };
};
var G = (e, t = "blank", o)=>({
        createdAt: Date.now(),
        visible: !0,
        type: t,
        ariaProps: {
            role: "status",
            "aria-live": "polite"
        },
        message: e,
        pauseDuration: 0,
        ...o,
        id: (o == null ? void 0 : o.id) || U()
    }), h = (e)=>(t, o)=>{
        let s = G(t, e, o);
        return u({
            type: 2,
            toast: s
        }), s.id;
    }, n = (e, t)=>h("blank")(e, t);
n.error = h("error");
n.success = h("success");
n.loading = h("loading");
n.custom = h("custom");
n.dismiss = (e)=>{
    u({
        type: 3,
        toastId: e
    });
};
n.remove = (e)=>u({
        type: 4,
        toastId: e
    });
n.promise = (e, t, o)=>{
    let s = n.loading(t.loading, {
        ...o,
        ...o == null ? void 0 : o.loading
    });
    return e.then((a)=>(n.success(T(t.success, a), {
            id: s,
            ...o,
            ...o == null ? void 0 : o.success
        }), a)).catch((a)=>{
        n.error(T(t.error, a), {
            id: s,
            ...o,
            ...o == null ? void 0 : o.error
        });
    }), e;
};

var Z = (e, t)=>{
    u({
        type: 1,
        toast: {
            id: e,
            height: t
        }
    });
}, ee = ()=>{
    u({
        type: 5,
        time: Date.now()
    });
}, D = (e)=>{
    let { toasts: t, pausedAt: o } = I(e);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (o) return;
        let r = Date.now(), c = t.map((i)=>{
            if (i.duration === 1 / 0) return;
            let d = (i.duration || 0) + i.pauseDuration - (r - i.createdAt);
            if (d < 0) {
                i.visible && n.dismiss(i.id);
                return;
            }
            return setTimeout(()=>n.dismiss(i.id), d);
        });
        return ()=>{
            c.forEach((i)=>i && clearTimeout(i));
        };
    }, [
        t,
        o
    ]);
    let s = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        o && u({
            type: 6,
            time: Date.now()
        });
    }, [
        o
    ]), a = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((r, c)=>{
        let { reverseOrder: i = !1, gutter: d = 8, defaultPosition: p } = c || {}, g = t.filter((m)=>(m.position || p) === (r.position || p) && m.height), E = g.findIndex((m)=>m.id === r.id), x = g.filter((m, R)=>R < E && m.visible).length;
        return g.filter((m)=>m.visible).slice(...i ? [
            x + 1
        ] : [
            0,
            x
        ]).reduce((m, R)=>m + (R.height || 0) + d, 0);
    }, [
        t
    ]);
    return {
        toasts: t,
        handlers: {
            updateHeight: Z,
            startPause: ee,
            endPause: s,
            calculateOffset: a
        }
    };
};





var oe = (0,goober__WEBPACK_IMPORTED_MODULE_1__.keyframes)`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`, re = (0,goober__WEBPACK_IMPORTED_MODULE_1__.keyframes)`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`, se = (0,goober__WEBPACK_IMPORTED_MODULE_1__.keyframes)`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`, _ = (0,goober__WEBPACK_IMPORTED_MODULE_1__.styled)("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${(e)=>e.primary || "#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${oe} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${re} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${(e)=>e.secondary || "#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${se} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`;

var ne = (0,goober__WEBPACK_IMPORTED_MODULE_1__.keyframes)`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`, V = (0,goober__WEBPACK_IMPORTED_MODULE_1__.styled)("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${(e)=>e.secondary || "#e0e0e0"};
  border-right-color: ${(e)=>e.primary || "#616161"};
  animation: ${ne} 1s linear infinite;
`;

var pe = (0,goober__WEBPACK_IMPORTED_MODULE_1__.keyframes)`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`, de = (0,goober__WEBPACK_IMPORTED_MODULE_1__.keyframes)`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`, w = (0,goober__WEBPACK_IMPORTED_MODULE_1__.styled)("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${(e)=>e.primary || "#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${pe} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${de} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${(e)=>e.secondary || "#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`;
var ue = (0,goober__WEBPACK_IMPORTED_MODULE_1__.styled)("div")`
  position: absolute;
`, le = (0,goober__WEBPACK_IMPORTED_MODULE_1__.styled)("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`, Te = (0,goober__WEBPACK_IMPORTED_MODULE_1__.keyframes)`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`, fe = (0,goober__WEBPACK_IMPORTED_MODULE_1__.styled)("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${Te} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`, M = ({ toast: e })=>{
    let { icon: t, type: o, iconTheme: s } = e;
    return t !== void 0 ? typeof t == "string" ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(fe, null, t) : t : o === "blank" ? null : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(le, null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(V, {
        ...s
    }), o !== "loading" && /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(ue, null, o === "error" ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(_, {
        ...s
    }) : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(w, {
        ...s
    })));
};
var ye = (e)=>`
0% {transform: translate3d(0,${e * -200}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`, ge = (e)=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${e * -150}%,-1px) scale(.6); opacity:0;}
`, he = "0%{opacity:0;} 100%{opacity:1;}", xe = "0%{opacity:1;} 100%{opacity:0;}", be = (0,goober__WEBPACK_IMPORTED_MODULE_1__.styled)("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`, Se = (0,goober__WEBPACK_IMPORTED_MODULE_1__.styled)("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`, Ae = (e, t)=>{
    let s = e.includes("top") ? 1 : -1, [a, r] = b() ? [
        he,
        xe
    ] : [
        ye(s),
        ge(s)
    ];
    return {
        animation: t ? `${(0,goober__WEBPACK_IMPORTED_MODULE_1__.keyframes)(a)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards` : `${(0,goober__WEBPACK_IMPORTED_MODULE_1__.keyframes)(r)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`
    };
}, F = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.memo(({ toast: e, position: t, style: o, children: s })=>{
    let a = e.height ? Ae(e.position || t || "top-center", e.visible) : {
        opacity: 0
    }, r = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(M, {
        toast: e
    }), c = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(Se, {
        ...e.ariaProps
    }, T(e.message, e));
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(be, {
        className: e.className,
        style: {
            ...a,
            ...o,
            ...e.style
        }
    }, typeof s == "function" ? s({
        icon: r,
        message: c
    }) : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, r, c));
});


(0,goober__WEBPACK_IMPORTED_MODULE_1__.setup)(react__WEBPACK_IMPORTED_MODULE_0__.createElement);
var Ee = ({ id: e, className: t, style: o, onHeightUpdate: s, children: a })=>{
    let r = react__WEBPACK_IMPORTED_MODULE_0__.useCallback((c)=>{
        if (c) {
            let i = ()=>{
                let d = c.getBoundingClientRect().height;
                s(e, d);
            };
            i(), new MutationObserver(i).observe(c, {
                subtree: !0,
                childList: !0,
                characterData: !0
            });
        }
    }, [
        e,
        s
    ]);
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        ref: r,
        className: t,
        style: o
    }, a);
}, Re = (e, t)=>{
    let o = e.includes("top"), s = o ? {
        top: 0
    } : {
        bottom: 0
    }, a = e.includes("center") ? {
        justifyContent: "center"
    } : e.includes("right") ? {
        justifyContent: "flex-end"
    } : {};
    return {
        left: 0,
        right: 0,
        display: "flex",
        position: "absolute",
        transition: b() ? void 0 : "all 230ms cubic-bezier(.21,1.02,.73,1)",
        transform: `translateY(${t * (o ? 1 : -1)}px)`,
        ...s,
        ...a
    };
}, ve = (0,goober__WEBPACK_IMPORTED_MODULE_1__.css)`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`, O = 16, Ie = ({ reverseOrder: e, position: t = "top-center", toastOptions: o, gutter: s, children: a, containerStyle: r, containerClassName: c })=>{
    let { toasts: i, handlers: d } = D(o);
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        style: {
            position: "fixed",
            zIndex: 9999,
            top: O,
            left: O,
            right: O,
            bottom: O,
            pointerEvents: "none",
            ...r
        },
        className: c,
        onMouseEnter: d.startPause,
        onMouseLeave: d.endPause
    }, i.map((p)=>{
        let g = p.position || t, E = d.calculateOffset(p, {
            reverseOrder: e,
            gutter: s,
            defaultPosition: t
        }), x = Re(g, E);
        return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(Ee, {
            id: p.id,
            key: p.id,
            onHeightUpdate: d.updateHeight,
            className: p.visible ? ve : "",
            style: x
        }, p.type === "custom" ? T(p.message, p) : a ? a(p) : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.createElement(F, {
            toast: p,
            position: g
        }));
    }));
};
var _t = n;
 //# sourceMappingURL=index.mjs.map


/***/ })

};
;