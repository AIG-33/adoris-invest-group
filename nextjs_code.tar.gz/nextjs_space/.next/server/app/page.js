(() => {
var exports = {};
exports.id = "app/page";
exports.ids = ["app/page"];
exports.modules = {

/***/ "@prisma/client":
/*!*********************************!*\
  !*** external "@prisma/client" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@prisma/client");

/***/ }),

/***/ "../../client/components/action-async-storage.external":
/*!*******************************************************************************!*\
  !*** external "next/dist/client/components/action-async-storage.external.js" ***!
  \*******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/action-async-storage.external.js");

/***/ }),

/***/ "../../client/components/request-async-storage.external":
/*!********************************************************************************!*\
  !*** external "next/dist/client/components/request-async-storage.external.js" ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/request-async-storage.external.js");

/***/ }),

/***/ "../../client/components/static-generation-async-storage.external":
/*!******************************************************************************************!*\
  !*** external "next/dist/client/components/static-generation-async-storage.external.js" ***!
  \******************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/static-generation-async-storage.external.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fpage&page=%2Fpage&appPaths=%2Fpage&pagePath=private-next-app-dir%2Fpage.tsx&appDir=%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fpage&page=%2Fpage&appPaths=%2Fpage&pagePath=private-next-app-dir%2Fpage.tsx&appDir=%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-page/module.compiled */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/module.compiled.js?0264");
/* harmony import */ var next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-kind.js");
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/client/components/error-boundary */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/error-boundary.js");
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/dist/server/app-render/entry-base */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/app-render/entry-base.js");
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
"TURBOPACK { transition: next-ssr }";


// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/page.tsx */ "(rsc)/./app/page.tsx")), "/home/ubuntu/ivdgroup_mvp/nextjs_space/app/page.tsx"],
          
        }]
      },
        {
        'layout': [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/layout.tsx */ "(rsc)/./app/layout.tsx")), "/home/ubuntu/ivdgroup_mvp/nextjs_space/app/layout.tsx"],
'not-found': [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! next/dist/client/components/not-found-error */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/not-found-error.js", 23)), "next/dist/client/components/not-found-error"],
        
      }
      ]
      }.children;
const pages = ["/home/ubuntu/ivdgroup_mvp/nextjs_space/app/page.tsx"];


const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/page",
        pathname: "/",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fcomponents%2Fcategory-showcase.tsx%22%2C%22ids%22%3A%5B%22CategoryShowcase%22%5D%7D&modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fcomponents%2Ffeatured-products.tsx%22%2C%22ids%22%3A%5B%22FeaturedProducts%22%5D%7D&modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fcomponents%2Fheader.tsx%22%2C%22ids%22%3A%5B%22Header%22%5D%7D&modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fcomponents%2Fhero-section.tsx%22%2C%22ids%22%3A%5B%22HeroSection%22%5D%7D&modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fcomponents%2Fstats-section.tsx%22%2C%22ids%22%3A%5B%22StatsSection%22%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fimage-component.js%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Flink.js%22%2C%22ids%22%3A%5B%22*%22%5D%7D&server=true!":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fcomponents%2Fcategory-showcase.tsx%22%2C%22ids%22%3A%5B%22CategoryShowcase%22%5D%7D&modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fcomponents%2Ffeatured-products.tsx%22%2C%22ids%22%3A%5B%22FeaturedProducts%22%5D%7D&modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fcomponents%2Fheader.tsx%22%2C%22ids%22%3A%5B%22Header%22%5D%7D&modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fcomponents%2Fhero-section.tsx%22%2C%22ids%22%3A%5B%22HeroSection%22%5D%7D&modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fcomponents%2Fstats-section.tsx%22%2C%22ids%22%3A%5B%22StatsSection%22%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fimage-component.js%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Flink.js%22%2C%22ids%22%3A%5B%22*%22%5D%7D&server=true! ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./components/category-showcase.tsx */ "(ssr)/./components/category-showcase.tsx"));
;
Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./components/featured-products.tsx */ "(ssr)/./components/featured-products.tsx"));
;
Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./components/header.tsx */ "(ssr)/./components/header.tsx"));
;
Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./components/hero-section.tsx */ "(ssr)/./components/hero-section.tsx"));
;
Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./components/stats-section.tsx */ "(ssr)/./components/stats-section.tsx"));
;
Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/image-component.js */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/image-component.js", 23));
;
Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/link.js */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/link.js", 23));


/***/ }),

/***/ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fcomponents%2Fproviders.tsx%22%2C%22ids%22%3A%5B%22Providers%22%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Ffont%2Fgoogle%2Ftarget.css%3F%7B%5C%22path%5C%22%3A%5C%22app%2Flayout.tsx%5C%22%2C%5C%22import%5C%22%3A%5C%22Inter%5C%22%2C%5C%22arguments%5C%22%3A%5B%7B%5C%22subsets%5C%22%3A%5B%5C%22latin%5C%22%5D%7D%5D%2C%5C%22variableName%5C%22%3A%5C%22inter%5C%22%7D%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fapp%2Fglobals.css%22%2C%22ids%22%3A%5B%5D%7D&server=true!":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fcomponents%2Fproviders.tsx%22%2C%22ids%22%3A%5B%22Providers%22%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Ffont%2Fgoogle%2Ftarget.css%3F%7B%5C%22path%5C%22%3A%5C%22app%2Flayout.tsx%5C%22%2C%5C%22import%5C%22%3A%5C%22Inter%5C%22%2C%5C%22arguments%5C%22%3A%5B%7B%5C%22subsets%5C%22%3A%5B%5C%22latin%5C%22%5D%7D%5D%2C%5C%22variableName%5C%22%3A%5C%22inter%5C%22%7D%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fapp%2Fglobals.css%22%2C%22ids%22%3A%5B%5D%7D&server=true! ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./components/providers.tsx */ "(ssr)/./components/providers.tsx"));


/***/ }),

/***/ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fapp-router.js%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fclient-page.js%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Ferror-boundary.js%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Flayout-router.js%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fnot-found-boundary.js%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Frender-from-template-context.js%22%2C%22ids%22%3A%5B%5D%7D&server=true!":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fapp-router.js%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fclient-page.js%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Ferror-boundary.js%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Flayout-router.js%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fnot-found-boundary.js%22%2C%22ids%22%3A%5B%5D%7D&modules=%7B%22request%22%3A%22%2Fopt%2Fhostedapp%2Fnode%2Froot%2Fapp%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Frender-from-template-context.js%22%2C%22ids%22%3A%5B%5D%7D&server=true! ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/app-router.js */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/app-router.js", 23));
;
Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/client-page.js */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/client-page.js", 23));
;
Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/error-boundary.js */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/error-boundary.js", 23));
;
Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/layout-router.js */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/layout-router.js", 23));
;
Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/not-found-boundary.js */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/not-found-boundary.js", 23));
;
Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/render-from-template-context.js */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/client/components/render-from-template-context.js", 23));


/***/ }),

/***/ "(ssr)/./components/category-showcase.tsx":
/*!******************************************!*\
  !*** ./components/category-showcase.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CategoryShowcase: () => (/* binding */ CategoryShowcase)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/api/image.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/api/link.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _barrel_optimize_names_ChevronLeft_ChevronRight_lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=ChevronLeft,ChevronRight!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/chevron-left.js");
/* harmony import */ var _barrel_optimize_names_ChevronLeft_ChevronRight_lucide_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! __barrel_optimize__?names=ChevronLeft,ChevronRight!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/chevron-right.js");
/* __next_internal_client_entry_do_not_use__ CategoryShowcase auto */ 




function CategoryShowcase({ categories }) {
    if (categories.length === 0) return null;
    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("section", {
        className: "py-16",
        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "container mx-auto px-4 sm:px-6 lg:px-8",
            children: categories.map((category)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(CategoryRow, {
                    category: category
                }, category.id, false, {
                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                    lineNumber: 35,
                    columnNumber: 11
                }, this))
        }, void 0, false, {
            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
            lineNumber: 33,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
        lineNumber: 32,
        columnNumber: 5
    }, this);
}
function CategoryRow({ category }) {
    const scrollRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null);
    const scroll = (direction)=>{
        if (scrollRef.current) {
            const scrollAmount = 350;
            scrollRef.current.scrollBy({
                left: direction === "left" ? -scrollAmount : scrollAmount,
                behavior: "smooth"
            });
        }
    };
    if (category.products.length === 0) return null;
    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "mb-12",
        children: [
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "mb-6 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
                        className: "text-2xl font-bold text-white md:text-3xl",
                        children: category.name
                    }, void 0, false, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                        lineNumber: 61,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: `/products?category=${category.slug}`,
                        className: "text-[#666666] transition-colors hover:text-[#333333]",
                        children: "Explore All →"
                    }, void 0, false, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "group relative",
                children: [
                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
                        onClick: ()=>scroll("left"),
                        className: "absolute -left-4 top-1/2 z-10 hidden -translate-y-1/2 rounded-full bg-black/80 p-2 text-white opacity-0 backdrop-blur-sm transition-all hover:bg-[#000000] group-hover:opacity-100 lg:block",
                        "aria-label": "Scroll left",
                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_ChevronLeft_ChevronRight_lucide_react__WEBPACK_IMPORTED_MODULE_4__["default"], {
                            className: "h-5 w-5"
                        }, void 0, false, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                            lineNumber: 80,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                        lineNumber: 75,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
                        onClick: ()=>scroll("right"),
                        className: "absolute -right-4 top-1/2 z-10 hidden -translate-y-1/2 rounded-full bg-black/80 p-2 text-white opacity-0 backdrop-blur-sm transition-all hover:bg-[#000000] group-hover:opacity-100 lg:block",
                        "aria-label": "Scroll right",
                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_ChevronLeft_ChevronRight_lucide_react__WEBPACK_IMPORTED_MODULE_5__["default"], {
                            className: "h-5 w-5"
                        }, void 0, false, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                            lineNumber: 87,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                        lineNumber: 82,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        ref: scrollRef,
                        className: "flex gap-3 overflow-x-auto pb-4 scrollbar-hide",
                        style: {
                            scrollbarWidth: "none",
                            msOverflowStyle: "none"
                        },
                        children: category.products.map((product)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: `/product/${product.slug}`,
                                className: "group/item relative min-w-[200px] flex-shrink-0 overflow-hidden rounded-lg transition-all hover:scale-105 md:min-w-[240px]",
                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                    className: "relative aspect-[3/4] overflow-hidden bg-gray-800",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                            src: product.image,
                                            alt: product.name,
                                            fill: true,
                                            className: "object-cover transition-transform duration-500 group-hover/item:scale-110"
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                                            lineNumber: 104,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                            className: "absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                                            lineNumber: 111,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                            className: "absolute inset-x-0 bottom-0 p-3",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
                                                    className: "mb-1 text-sm font-semibold text-white line-clamp-2",
                                                    children: product.name
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                                                    lineNumber: 115,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                                                    className: "mb-1 text-xs text-gray-300",
                                                    children: product.manufacturer.name
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                                                    lineNumber: 118,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                                                    className: "text-lg font-bold text-[#666666]",
                                                    children: [
                                                        "€",
                                                        product.price.toLocaleString()
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                                                    lineNumber: 121,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                                            lineNumber: 114,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                                    lineNumber: 103,
                                    columnNumber: 15
                                }, this)
                            }, product.id, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                                lineNumber: 97,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}


/***/ }),

/***/ "(ssr)/./components/featured-products.tsx":
/*!******************************************!*\
  !*** ./components/featured-products.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FeaturedProducts: () => (/* binding */ FeaturedProducts)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/api/image.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/api/link.js");
/* harmony import */ var _barrel_optimize_names_ChevronLeft_ChevronRight_ShoppingCart_lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=ChevronLeft,ChevronRight,ShoppingCart!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/chevron-left.js");
/* harmony import */ var _barrel_optimize_names_ChevronLeft_ChevronRight_ShoppingCart_lucide_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! __barrel_optimize__?names=ChevronLeft,ChevronRight,ShoppingCart!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/chevron-right.js");
/* harmony import */ var _barrel_optimize_names_ChevronLeft_ChevronRight_ShoppingCart_lucide_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! __barrel_optimize__?names=ChevronLeft,ChevronRight,ShoppingCart!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/shopping-cart.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* __next_internal_client_entry_do_not_use__ FeaturedProducts auto */ 




function FeaturedProducts({ products }) {
    const scrollRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null);
    const scroll = (direction)=>{
        if (scrollRef.current) {
            const scrollAmount = 400;
            scrollRef.current.scrollBy({
                left: direction === "left" ? -scrollAmount : scrollAmount,
                behavior: "smooth"
            });
        }
    };
    const handleAddToCart = (product, e)=>{
        e.preventDefault();
        e.stopPropagation();
        const cart = JSON.parse(localStorage.getItem("cart") || "[]");
        const existingItem = cart.find((item)=>item.id === product.id);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                ...product,
                quantity: 1
            });
        }
        localStorage.setItem("cart", JSON.stringify(cart));
        window.dispatchEvent(new Event("cartUpdated"));
        // Visual feedback
        const button = e.currentTarget;
        button.classList.add("scale-90");
        setTimeout(()=>button.classList.remove("scale-90"), 200);
    };
    if (products.length === 0) {
        return null;
    }
    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("section", {
        className: "relative py-16",
        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "container mx-auto px-4 sm:px-6 lg:px-8",
            children: [
                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "mb-8 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
                                    className: "text-3xl font-bold text-white md:text-4xl",
                                    children: "Featured Products"
                                }, void 0, false, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                    lineNumber: 68,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                                    className: "mt-2 text-lg text-gray-400",
                                    children: "Premium medical equipment from top manufacturers"
                                }, void 0, false, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                    lineNumber: 71,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            href: "/products",
                            className: "hidden text-[#666666] transition-colors hover:text-[#333333] md:block",
                            children: "View All →"
                        }, void 0, false, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                            lineNumber: 75,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                    lineNumber: 66,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "group relative",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
                            onClick: ()=>scroll("left"),
                            className: "absolute -left-4 top-1/2 z-10 hidden -translate-y-1/2 rounded-full bg-black/80 p-3 text-white opacity-0 backdrop-blur-sm transition-all hover:bg-[#000000] group-hover:opacity-100 lg:block",
                            "aria-label": "Scroll left",
                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_ChevronLeft_ChevronRight_ShoppingCart_lucide_react__WEBPACK_IMPORTED_MODULE_4__["default"], {
                                className: "h-6 w-6"
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                lineNumber: 91,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                            lineNumber: 86,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
                            onClick: ()=>scroll("right"),
                            className: "absolute -right-4 top-1/2 z-10 hidden -translate-y-1/2 rounded-full bg-black/80 p-3 text-white opacity-0 backdrop-blur-sm transition-all hover:bg-[#000000] group-hover:opacity-100 lg:block",
                            "aria-label": "Scroll right",
                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_ChevronLeft_ChevronRight_ShoppingCart_lucide_react__WEBPACK_IMPORTED_MODULE_5__["default"], {
                                className: "h-6 w-6"
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                lineNumber: 98,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                            lineNumber: 93,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            ref: scrollRef,
                            className: "flex gap-4 overflow-x-auto pb-4 scrollbar-hide",
                            style: {
                                scrollbarWidth: "none",
                                msOverflowStyle: "none"
                            },
                            children: products.map((product)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: `/product/${product.slug}`,
                                    className: "group/card relative min-w-[280px] flex-shrink-0 overflow-hidden rounded-xl bg-gradient-to-b from-gray-800/50 to-gray-900/50 backdrop-blur-sm transition-all hover:scale-105 hover:shadow-2xl hover:shadow-[#000000]/20 md:min-w-[320px]",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                            className: "relative aspect-[4/3] overflow-hidden bg-gray-800",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                                    src: product.image,
                                                    alt: product.name,
                                                    fill: true,
                                                    className: "object-cover transition-transform duration-500 group-hover/card:scale-110"
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                                    lineNumber: 115,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                                    className: "absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                                    lineNumber: 122,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                                    className: "absolute left-3 top-3 rounded-full bg-[#000000]/90 px-3 py-1 text-xs font-semibold text-white backdrop-blur-sm",
                                                    children: product.category.name
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                                    lineNumber: 125,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
                                                    onClick: (e)=>handleAddToCart(product, e),
                                                    className: "absolute bottom-3 right-3 rounded-full bg-white/90 p-2 text-[#000000] opacity-0 transition-all hover:bg-white hover:scale-110 group-hover/card:opacity-100",
                                                    "aria-label": "Add to cart",
                                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_ChevronLeft_ChevronRight_ShoppingCart_lucide_react__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                                        className: "h-5 w-5"
                                                    }, void 0, false, {
                                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                                        lineNumber: 135,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                                    lineNumber: 130,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                            lineNumber: 114,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                            className: "p-4",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
                                                    className: "mb-1 font-semibold text-white line-clamp-2",
                                                    children: product.name
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                                    lineNumber: 141,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                                                    className: "mb-2 text-sm text-gray-400",
                                                    children: product.manufacturer.name
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                                    lineNumber: 144,
                                                    columnNumber: 19
                                                }, this),
                                                product.shortDesc && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                                                    className: "mb-3 text-sm text-gray-300 line-clamp-2",
                                                    children: product.shortDesc
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                                    lineNumber: 148,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                                    className: "flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                            className: "text-2xl font-bold text-[#666666]",
                                                            children: [
                                                                "€",
                                                                product.price.toLocaleString()
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                                            lineNumber: 153,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                            className: "text-sm text-gray-400",
                                                            children: "By Order"
                                                        }, void 0, false, {
                                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                                            lineNumber: 156,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                                    lineNumber: 152,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                            lineNumber: 140,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, product.id, true, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                                    lineNumber: 108,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                            lineNumber: 102,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
                    lineNumber: 84,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
            lineNumber: 64,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx",
        lineNumber: 63,
        columnNumber: 5
    }, this);
}


/***/ }),

/***/ "(ssr)/./components/header.tsx":
/*!*******************************!*\
  !*** ./components/header.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Header: () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/api/link.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/api/image.js");
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next-auth/react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next-auth/react/index.js");
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! __barrel_optimize__?names=Calendar,ChevronDown,LogOut,Package,Search,ShoppingCart,User!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/search.js");
/* harmony import */ var _barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! __barrel_optimize__?names=Calendar,ChevronDown,LogOut,Package,Search,ShoppingCart,User!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/package.js");
/* harmony import */ var _barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! __barrel_optimize__?names=Calendar,ChevronDown,LogOut,Package,Search,ShoppingCart,User!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/calendar.js");
/* harmony import */ var _barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! __barrel_optimize__?names=Calendar,ChevronDown,LogOut,Package,Search,ShoppingCart,User!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/user.js");
/* harmony import */ var _barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! __barrel_optimize__?names=Calendar,ChevronDown,LogOut,Package,Search,ShoppingCart,User!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/chevron-down.js");
/* harmony import */ var _barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! __barrel_optimize__?names=Calendar,ChevronDown,LogOut,Package,Search,ShoppingCart,User!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/shopping-cart.js");
/* harmony import */ var _barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! __barrel_optimize__?names=Calendar,ChevronDown,LogOut,Package,Search,ShoppingCart,User!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/log-out.js");
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/navigation */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/api/navigation.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/ui/dropdown-menu */ "(ssr)/./components/ui/dropdown-menu.tsx");
/* __next_internal_client_entry_do_not_use__ Header auto */ 







function Header() {
    const { data: session, status } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_3__.useSession)() || {};
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const [searchQuery, setSearchQuery] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    const [cartCount, setCartCount] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0);
    const [searchResults, setSearchResults] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)([]);
    const [showDropdown, setShowDropdown] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const [isSearching, setIsSearching] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const searchRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const timeoutRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)();
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        // Update cart count from localStorage
        const updateCartCount = ()=>{
            const cart = JSON.parse(localStorage?.getItem?.("cart") || "[]");
            setCartCount(cart?.length || 0);
        };
        updateCartCount();
        // Listen for cart updates
        window?.addEventListener?.("cartUpdated", updateCartCount);
        return ()=>window?.removeEventListener?.("cartUpdated", updateCartCount);
    }, []);
    // Click outside to close dropdown
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        const handleClickOutside = (event)=>{
            if (searchRef.current && !searchRef.current.contains(event.target)) {
                setShowDropdown(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>document.removeEventListener("mousedown", handleClickOutside);
    }, []);
    // Debounced search
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
        }
        if (searchQuery.length < 2) {
            setSearchResults([]);
            setShowDropdown(false);
            return;
        }
        setIsSearching(true);
        timeoutRef.current = setTimeout(async ()=>{
            try {
                const response = await fetch(`/api/products/search?q=${encodeURIComponent(searchQuery)}`);
                if (response.ok) {
                    const results = await response.json();
                    setSearchResults(results);
                    setShowDropdown(results.length > 0);
                }
            } catch (error) {
                console.error("Search error:", error);
            } finally{
                setIsSearching(false);
            }
        }, 300);
        return ()=>{
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }
        };
    }, [
        searchQuery
    ]);
    const handleSearch = (e)=>{
        e?.preventDefault?.();
        if (searchQuery?.trim()) {
            setShowDropdown(false);
            router?.push?.(`/?search=${encodeURIComponent(searchQuery?.trim() || "")}`);
        }
    };
    const handleResultClick = (slug)=>{
        setShowDropdown(false);
        setSearchQuery("");
        router.push(`/product/${slug}`);
    };
    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("header", {
        className: "bg-white border-b border-neutral-200 sticky top-0 z-50 shadow-sm",
        children: [
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "bg-black text-white hidden md:block",
                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "container mx-auto px-4 sm:px-6 py-2",
                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        className: "flex justify-between items-center text-xs lg:text-sm",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                className: "flex items-center gap-2 lg:gap-4",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                        className: "truncate",
                                        children: "\uD83D\uDCE7 ceo@adorisgroup.com"
                                    }, void 0, false, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                        lineNumber: 121,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                        className: "hidden sm:inline",
                                        children: "\uD83D\uDCDE +48 881 049 959"
                                    }, void 0, false, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                        lineNumber: 122,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                lineNumber: 120,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                className: "hidden lg:flex items-center gap-4",
                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                    children: "ADORIS INVEST GROUP O\xdc | Tallinn, Estonia"
                                }, void 0, false, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                    lineNumber: 125,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                lineNumber: 124,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                        lineNumber: 119,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                    lineNumber: 118,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "container mx-auto px-4 sm:px-6 py-3 sm:py-4",
                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between sm:gap-4",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            href: "/",
                            className: "flex items-center gap-3 group flex-shrink-0",
                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                className: "relative w-32 h-8 sm:w-40 sm:h-10 lg:w-48 lg:h-12",
                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    src: "/logo.png",
                                    alt: "IVD GROUP",
                                    fill: true,
                                    className: "object-contain group-hover:scale-105 transition-transform",
                                    priority: true
                                }, void 0, false, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                    lineNumber: 137,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                lineNumber: 136,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                            lineNumber: 135,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            ref: searchRef,
                            className: "flex-1 w-full sm:max-w-md lg:max-w-2xl relative order-3 sm:order-2",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("form", {
                                    onSubmit: handleSearch,
                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("input", {
                                                type: "text",
                                                value: searchQuery,
                                                onChange: (e)=>setSearchQuery(e?.target?.value || ""),
                                                onFocus: ()=>{
                                                    if (searchResults.length > 0) {
                                                        setShowDropdown(true);
                                                    }
                                                },
                                                placeholder: "Search products...",
                                                className: "w-full px-3 py-2 sm:py-3 pl-10 sm:pl-12 pr-20 sm:pr-24 text-sm sm:text-base border-2 border-neutral-200 rounded-lg focus:border-[#333333] focus:outline-none focus:ring-2 sm:focus:ring-4 focus:ring-[#333333]/10 transition-all"
                                            }, void 0, false, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                lineNumber: 151,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_7__["default"], {
                                                className: "absolute left-3 sm:left-4 top-1/2 -translate-y-1/2 text-neutral-400 w-4 h-4 sm:w-5 sm:h-5"
                                            }, void 0, false, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                lineNumber: 163,
                                                columnNumber: 17
                                            }, this),
                                            isSearching ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                                className: "absolute right-2 top-1/2 -translate-y-1/2",
                                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                                    className: "w-4 h-4 sm:w-5 sm:h-5 border-2 border-[#333333] border-t-transparent rounded-full animate-spin"
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                    lineNumber: 166,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                lineNumber: 165,
                                                columnNumber: 19
                                            }, this) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
                                                type: "submit",
                                                className: "absolute right-1 sm:right-2 top-1/2 -translate-y-1/2 bg-[#333333] text-white px-3 sm:px-6 py-1.5 sm:py-2 rounded-md hover:bg-[#1a1a1a] transition-colors font-medium text-xs sm:text-sm",
                                                children: "Search"
                                            }, void 0, false, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                lineNumber: 169,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                        lineNumber: 150,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                    lineNumber: 149,
                                    columnNumber: 13
                                }, this),
                                showDropdown && searchResults.length > 0 && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                    className: "absolute top-full left-0 right-0 mt-2 bg-white border border-neutral-200 rounded-lg shadow-xl max-h-80 sm:max-h-96 overflow-y-auto z-50",
                                    children: searchResults.map((product)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
                                            onClick: ()=>handleResultClick(product.slug),
                                            className: "w-full flex items-center gap-2 sm:gap-4 p-2 sm:p-3 hover:bg-neutral-50 transition-colors border-b border-neutral-100 last:border-b-0 text-left",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                                    className: "relative w-12 h-12 sm:w-16 sm:h-16 flex-shrink-0 bg-neutral-100 rounded-lg overflow-hidden",
                                                    children: product.imageUrl ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                                        src: product.imageUrl,
                                                        alt: product.name,
                                                        fill: true,
                                                        className: "object-cover"
                                                    }, void 0, false, {
                                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                        lineNumber: 190,
                                                        columnNumber: 25
                                                    }, this) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                                        className: "w-full h-full flex items-center justify-center text-neutral-400",
                                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_8__["default"], {
                                                            className: "w-6 h-6 sm:w-8 sm:h-8"
                                                        }, void 0, false, {
                                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                            lineNumber: 198,
                                                            columnNumber: 27
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                        lineNumber: 197,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                    lineNumber: 188,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                                    className: "flex-1 min-w-0",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                                            className: "font-semibold text-[#000000] truncate text-sm sm:text-base",
                                                            children: product.name
                                                        }, void 0, false, {
                                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                            lineNumber: 203,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                                            className: "text-xs sm:text-sm text-neutral-600 flex items-center gap-1 sm:gap-2 mt-1",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                                    className: "font-mono bg-neutral-100 px-1.5 sm:px-2 py-0.5 rounded text-xs",
                                                                    children: product.sku
                                                                }, void 0, false, {
                                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                    lineNumber: 205,
                                                                    columnNumber: 25
                                                                }, this),
                                                                product.manufacturer && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                                    className: "text-xs truncate",
                                                                    children: product.manufacturer.name
                                                                }, void 0, false, {
                                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                    lineNumber: 209,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                            lineNumber: 204,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                    lineNumber: 202,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                                    className: "text-right flex-shrink-0",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                                            className: "font-bold text-[#000000] text-sm sm:text-base",
                                                            children: [
                                                                "€",
                                                                product.price.toFixed(2)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                            lineNumber: 214,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                                            className: "text-xs text-neutral-500 hidden sm:block",
                                                            children: "excl. VAT"
                                                        }, void 0, false, {
                                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                            lineNumber: 215,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                    lineNumber: 213,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, product.id, true, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                            lineNumber: 183,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                    lineNumber: 181,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                            lineNumber: 148,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "flex items-center gap-2 sm:gap-3 lg:gap-4 order-2 sm:order-3",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                    href: "/",
                                    className: "flex items-center gap-1 sm:gap-2 text-neutral-700 hover:text-[#666666] font-medium transition-colors text-xs sm:text-sm lg:text-base",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_8__["default"], {
                                            className: "w-4 h-4 sm:w-5 sm:h-5"
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                            lineNumber: 229,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                            className: "hidden sm:inline",
                                            children: "Catalog"
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                            lineNumber: 230,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                    lineNumber: 225,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                    href: "/exhibitions",
                                    className: "flex items-center gap-1 sm:gap-2 text-neutral-700 hover:text-[#666666] font-medium transition-colors text-xs sm:text-sm lg:text-base",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_9__["default"], {
                                            className: "w-4 h-4 sm:w-5 sm:h-5"
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                            lineNumber: 237,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                            className: "hidden sm:inline",
                                            children: "Exhibitions"
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                            lineNumber: 238,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                    lineNumber: 233,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                    href: "/terms",
                                    className: "hidden md:flex items-center gap-2 text-neutral-700 hover:text-[#333333] font-medium transition-colors",
                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                        children: "Terms"
                                    }, void 0, false, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                        lineNumber: 245,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                    lineNumber: 241,
                                    columnNumber: 13
                                }, this),
                                status === "authenticated" && session?.user ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__.DropdownMenu, {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__.DropdownMenuTrigger, {
                                                className: "flex items-center gap-1 sm:gap-2 text-neutral-700 hover:text-[#333333] font-medium transition-colors outline-none text-xs sm:text-sm lg:text-base",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_10__["default"], {
                                                        className: "w-4 h-4 sm:w-5 sm:h-5"
                                                    }, void 0, false, {
                                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                        lineNumber: 253,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                        className: "hidden sm:inline",
                                                        children: "My Account"
                                                    }, void 0, false, {
                                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                        lineNumber: 254,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_11__["default"], {
                                                        className: "w-3 h-3 sm:w-4 sm:h-4"
                                                    }, void 0, false, {
                                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                        lineNumber: 255,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                lineNumber: 252,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__.DropdownMenuContent, {
                                                align: "end",
                                                className: "w-48 sm:w-56",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__.DropdownMenuItem, {
                                                        asChild: true,
                                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                                            href: "/bulk-order",
                                                            className: "flex items-center gap-2 cursor-pointer",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_8__["default"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                    lineNumber: 260,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                                    children: "Bulk Order"
                                                                }, void 0, false, {
                                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                    lineNumber: 261,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                            lineNumber: 259,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                        lineNumber: 258,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__.DropdownMenuItem, {
                                                        asChild: true,
                                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                                            href: "/cart",
                                                            className: "flex items-center gap-2 cursor-pointer relative",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                    lineNumber: 266,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                                    children: "Cart"
                                                                }, void 0, false, {
                                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                    lineNumber: 267,
                                                                    columnNumber: 25
                                                                }, this),
                                                                cartCount > 0 && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                                    className: "ml-auto bg-[#333333] text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center",
                                                                    children: cartCount
                                                                }, void 0, false, {
                                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                    lineNumber: 269,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                            lineNumber: 265,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                        lineNumber: 264,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__.DropdownMenuSeparator, {}, void 0, false, {
                                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                        lineNumber: 275,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__.DropdownMenuItem, {
                                                        asChild: true,
                                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                                            href: "/account",
                                                            className: "flex items-center gap-2 cursor-pointer",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_10__["default"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                    lineNumber: 278,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                                    children: "My Account"
                                                                }, void 0, false, {
                                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                    lineNumber: 279,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                            lineNumber: 277,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                        lineNumber: 276,
                                                        columnNumber: 21
                                                    }, this),
                                                    session?.user?.role === "admin" && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__.DropdownMenuSeparator, {}, void 0, false, {
                                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                lineNumber: 284,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__.DropdownMenuItem, {
                                                                asChild: true,
                                                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                                                    href: "/admin",
                                                                    className: "flex items-center gap-2 cursor-pointer text-[#000000] font-semibold",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_10__["default"], {
                                                                            className: "w-4 h-4"
                                                                        }, void 0, false, {
                                                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                            lineNumber: 287,
                                                                            columnNumber: 29
                                                                        }, this),
                                                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                                            children: "Admin Panel"
                                                                        }, void 0, false, {
                                                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                            lineNumber: 288,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                    lineNumber: 286,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                lineNumber: 285,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true),
                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__.DropdownMenuSeparator, {}, void 0, false, {
                                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                        lineNumber: 293,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui_dropdown_menu__WEBPACK_IMPORTED_MODULE_6__.DropdownMenuItem, {
                                                        onClick: ()=>(0,next_auth_react__WEBPACK_IMPORTED_MODULE_3__.signOut)(),
                                                        className: "flex items-center gap-2 cursor-pointer text-red-600 focus:text-red-600",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_13__["default"], {
                                                                className: "w-4 h-4"
                                                            }, void 0, false, {
                                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                lineNumber: 298,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                                children: "Logout"
                                                            }, void 0, false, {
                                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                                lineNumber: 299,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                        lineNumber: 294,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                                lineNumber: 257,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                        lineNumber: 251,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                    href: "/auth/login",
                                    className: "flex items-center gap-1 sm:gap-2 text-neutral-700 hover:text-[#333333] font-medium transition-colors text-xs sm:text-sm lg:text-base",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Calendar_ChevronDown_LogOut_Package_Search_ShoppingCart_User_lucide_react__WEBPACK_IMPORTED_MODULE_10__["default"], {
                                            className: "w-4 h-4 sm:w-5 sm:h-5"
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                            lineNumber: 309,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                            className: "hidden sm:inline",
                                            children: "Login"
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                            lineNumber: 310,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                                    lineNumber: 305,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                            lineNumber: 224,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                    lineNumber: 133,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
                lineNumber: 132,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx",
        lineNumber: 115,
        columnNumber: 5
    }, this);
}


/***/ }),

/***/ "(ssr)/./components/hero-section.tsx":
/*!*************************************!*\
  !*** ./components/hero-section.tsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HeroSection: () => (/* binding */ HeroSection)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/api/image.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/api/link.js");
/* harmony import */ var _barrel_optimize_names_ArrowRight_Play_lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=ArrowRight,Play!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/arrow-right.js");
/* harmony import */ var _barrel_optimize_names_ArrowRight_Play_lucide_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! __barrel_optimize__?names=ArrowRight,Play!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/play.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* __next_internal_client_entry_do_not_use__ HeroSection auto */ 




const heroSlides = [
    {
        title: "MedNAIS™",
        subtitle: "Enhancing Medical SOPs and streamline healthcare operations",
        description: "MedNAIS™ must have FREE App for medical nurses and laboratory professionals",
        image: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=1920&h=1080&fit=crop",
        cta: "Learn More",
        link: "/products?category=equipment"
    },
    {
        title: "ILabU™ Kits",
        subtitle: "Open new revenues for your IVD business",
        description: "Easy to use at-home sample collection set, designed to make testing accessible from the comfort of your home",
        image: "https://immunoserv.com/wp-content/uploads/bb-plugin/cache/827A3079-landscape-db75b79966d420a6479b7be6c0af29a7-fqtkhsu3vy0j.jpg",
        cta: "Explore Products",
        link: "/products?category=pcr-molecular"
    },
    {
        title: "Reagents & Disposables",
        subtitle: "Premium Quality Medical Supplies",
        description: "Original products from top European manufacturers with full compliance",
        image: "https://images.unsplash.com/photo-1582719471384-894fbb16e074?w=1920&h=1080&fit=crop",
        cta: "Shop Now",
        link: "/products?category=reagents-disposables"
    }
];
function HeroSection() {
    const [currentSlide, setCurrentSlide] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const [isLoaded, setIsLoaded] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setIsLoaded(true);
        const timer = setInterval(()=>{
            setCurrentSlide((prev)=>(prev + 1) % heroSlides.length);
        }, 8000);
        return ()=>clearInterval(timer);
    }, []);
    const slide = heroSlides[currentSlide];
    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("section", {
        className: "relative h-[60vh] sm:h-[70vh] md:h-[80vh] lg:h-[90vh] min-h-[400px] sm:min-h-[500px] md:min-h-[600px] overflow-hidden",
        children: [
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "absolute inset-0",
                children: heroSlides.map((s, idx)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        className: `absolute inset-0 transition-opacity duration-1000 ${idx === currentSlide ? "opacity-100" : "opacity-0"}`,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                src: s.image,
                                alt: s.title,
                                fill: true,
                                className: "object-cover",
                                priority: idx === 0
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                                lineNumber: 61,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                className: "absolute inset-0 bg-gradient-to-r from-black via-black/90 md:via-black/80 to-black/50 md:to-transparent"
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                                lineNumber: 69,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                className: "absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                                lineNumber: 70,
                                columnNumber: 13
                            }, this)
                        ]
                    }, idx, true, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                        lineNumber: 55,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "relative z-10 flex h-full items-center",
                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "container mx-auto px-4 sm:px-6 lg:px-8",
                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        className: "max-w-3xl space-y-3 sm:space-y-4 md:space-y-6",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {
                                className: `text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold text-white transition-all duration-700 ${isLoaded ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`,
                                style: {
                                    transitionDelay: "200ms"
                                },
                                children: slide.title
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                                lineNumber: 80,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
                                className: `text-base sm:text-xl md:text-2xl lg:text-3xl font-medium text-[#666666] transition-all duration-700 ${isLoaded ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`,
                                style: {
                                    transitionDelay: "400ms"
                                },
                                children: slide.subtitle
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                                lineNumber: 90,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                                className: `text-sm sm:text-base md:text-lg lg:text-xl text-gray-300 transition-all duration-700 ${isLoaded ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`,
                                style: {
                                    transitionDelay: "600ms"
                                },
                                children: slide.description
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                                lineNumber: 100,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                className: `flex flex-col sm:flex-row gap-3 sm:gap-4 transition-all duration-700 ${isLoaded ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`,
                                style: {
                                    transitionDelay: "800ms"
                                },
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                        href: slide.link,
                                        className: "group flex items-center justify-center gap-2 rounded-md bg-[#000000] px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold text-white transition-all hover:bg-[#156b5f] hover:scale-105 hover:shadow-xl hover:shadow-[#000000]/50",
                                        children: [
                                            slide.cta,
                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_ArrowRight_Play_lucide_react__WEBPACK_IMPORTED_MODULE_4__["default"], {
                                                className: "h-4 w-4 sm:h-5 sm:w-5 transition-transform group-hover:translate-x-1"
                                            }, void 0, false, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                                                lineNumber: 121,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                                        lineNumber: 116,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                        href: "/products",
                                        className: "group flex items-center justify-center gap-2 rounded-md border-2 border-white/30 bg-white/10 px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold text-white backdrop-blur-sm transition-all hover:border-white/50 hover:bg-white/20",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_ArrowRight_Play_lucide_react__WEBPACK_IMPORTED_MODULE_5__["default"], {
                                                className: "h-4 w-4 sm:h-5 sm:w-5"
                                            }, void 0, false, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                                                lineNumber: 128,
                                                columnNumber: 17
                                            }, this),
                                            "Browse Catalog"
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                                        lineNumber: 124,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                                lineNumber: 110,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                        lineNumber: 78,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                    lineNumber: 77,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "absolute bottom-4 sm:bottom-8 left-1/2 z-20 flex -translate-x-1/2 gap-2",
                children: heroSlides.map((_, idx)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
                        onClick: ()=>setCurrentSlide(idx),
                        className: `h-1 rounded-full transition-all ${idx === currentSlide ? "w-8 sm:w-12 bg-[#000000]" : "w-6 sm:w-8 bg-white/30 hover:bg-white/50"}`,
                        "aria-label": `Go to slide ${idx + 1}`
                    }, idx, false, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                        lineNumber: 139,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                lineNumber: 137,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "hidden md:block absolute bottom-8 right-8 z-20 animate-bounce",
                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "flex flex-col items-center gap-2 text-white/60",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                            className: "text-xs uppercase tracking-wider",
                            children: "Scroll"
                        }, void 0, false, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                            lineNumber: 155,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            className: "h-8 w-5 rounded-full border-2 border-white/30",
                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                className: "mx-auto mt-1 h-2 w-1 animate-pulse rounded-full bg-white/60"
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                                lineNumber: 157,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                            lineNumber: 156,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                    lineNumber: 154,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
                lineNumber: 153,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}


/***/ }),

/***/ "(ssr)/./components/providers.tsx":
/*!**********************************!*\
  !*** ./components/providers.tsx ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Providers: () => (/* binding */ Providers)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next-auth/react/index.js");
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-hot-toast */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/react-hot-toast/dist/index.mjs");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* __next_internal_client_entry_do_not_use__ Providers auto */ 



function Providers({ children }) {
    const [mounted, setMounted] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setMounted(true);
    }, []);
    if (!mounted) {
        return null;
    }
    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_auth_react__WEBPACK_IMPORTED_MODULE_1__.SessionProvider, {
        children: [
            children,
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_hot_toast__WEBPACK_IMPORTED_MODULE_2__.Toaster, {
                position: "top-right",
                toastOptions: {
                    duration: 3000,
                    style: {
                        background: "#fff",
                        color: "#171717",
                        border: "1px solid #e5e5e5",
                        borderRadius: "0.75rem",
                        padding: "16px"
                    },
                    success: {
                        iconTheme: {
                            primary: "#000000",
                            secondary: "#fff"
                        }
                    }
                }
            }, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/providers.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/providers.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}


/***/ }),

/***/ "(ssr)/./components/stats-section.tsx":
/*!**************************************!*\
  !*** ./components/stats-section.tsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StatsSection: () => (/* binding */ StatsSection)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _barrel_optimize_names_Award_Building2_Globe_Shield_lucide_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Award,Building2,Globe,Shield!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/globe.js");
/* harmony import */ var _barrel_optimize_names_Award_Building2_Globe_Shield_lucide_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Award,Building2,Globe,Shield!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/building-2.js");
/* harmony import */ var _barrel_optimize_names_Award_Building2_Globe_Shield_lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=Award,Building2,Globe,Shield!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/shield.js");
/* harmony import */ var _barrel_optimize_names_Award_Building2_Globe_Shield_lucide_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! __barrel_optimize__?names=Award,Building2,Globe,Shield!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/award.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ StatsSection auto */ 


const stats = [
    {
        icon: _barrel_optimize_names_Award_Building2_Globe_Shield_lucide_react__WEBPACK_IMPORTED_MODULE_2__["default"],
        value: "100,000+",
        label: "Medical Products",
        description: "Comprehensive catalog"
    },
    {
        icon: _barrel_optimize_names_Award_Building2_Globe_Shield_lucide_react__WEBPACK_IMPORTED_MODULE_3__["default"],
        value: "50+",
        label: "European Manufacturers",
        description: "Original products only"
    },
    {
        icon: _barrel_optimize_names_Award_Building2_Globe_Shield_lucide_react__WEBPACK_IMPORTED_MODULE_4__["default"],
        value: "100%",
        label: "Compliance",
        description: "Full regulatory approval"
    },
    {
        icon: _barrel_optimize_names_Award_Building2_Globe_Shield_lucide_react__WEBPACK_IMPORTED_MODULE_5__["default"],
        value: "4-7",
        label: "Weeks Delivery",
        description: "To Vilnius warehouse"
    }
];
const features = [
    {
        title: "Original Products",
        description: "Only authentic products from verified European manufacturers"
    },
    {
        title: "Volume Discounts",
        description: "5% discount for €50k+ orders, 10% for €100k+ orders"
    },
    {
        title: "Cold Chain Compliance",
        description: "Full temperature control for sensitive medical products"
    },
    {
        title: "EXW Vilnius",
        description: "Flexible delivery terms with warehouse in Vilnius"
    }
];
function StatsSection() {
    const [isVisible, setIsVisible] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const sectionRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const observer = new IntersectionObserver(([entry])=>{
            if (entry.isIntersecting) {
                setIsVisible(true);
            }
        }, {
            threshold: 0.2
        });
        if (sectionRef.current) {
            observer.observe(sectionRef.current);
        }
        return ()=>observer.disconnect();
    }, []);
    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("section", {
        ref: sectionRef,
        className: "relative py-20",
        children: [
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "absolute inset-0 bg-gradient-to-b from-black via-[#0a1f1a] to-black opacity-50"
            }, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "container relative z-10 mx-auto px-4 sm:px-6 lg:px-8",
                children: [
                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        className: "mb-20 grid gap-8 sm:grid-cols-2 lg:grid-cols-4",
                        children: stats.map((stat, idx)=>{
                            const Icon = stat.icon;
                            return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                className: `group rounded-2xl border border-[#000000]/20 bg-gradient-to-br from-gray-900/50 to-black/50 p-6 backdrop-blur-sm transition-all duration-700 hover:border-[#000000]/50 hover:shadow-xl hover:shadow-[#000000]/20 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`,
                                style: {
                                    transitionDelay: `${idx * 100}ms`
                                },
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Icon, {
                                        className: "mb-4 h-12 w-12 text-[#666666] transition-transform group-hover:scale-110"
                                    }, void 0, false, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                        lineNumber: 93,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                        className: "mb-2 text-4xl font-bold text-white",
                                        children: stat.value
                                    }, void 0, false, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                        lineNumber: 94,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                        className: "mb-1 text-lg font-semibold text-[#666666]",
                                        children: stat.label
                                    }, void 0, false, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                        lineNumber: 97,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                        className: "text-sm text-gray-400",
                                        children: stat.description
                                    }, void 0, false, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                        lineNumber: 100,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, idx, true, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                lineNumber: 84,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                        lineNumber: 80,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
                                className: "mb-12 text-center text-3xl font-bold text-white md:text-4xl",
                                children: "Why Choose IVD Group"
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                lineNumber: 108,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                className: "grid gap-6 md:grid-cols-2",
                                children: features.map((feature, idx)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                        className: `group rounded-xl border border-[#000000]/20 bg-gradient-to-r from-gray-900/30 to-black/30 p-6 backdrop-blur-sm transition-all duration-700 hover:border-[#000000]/50 hover:bg-gradient-to-r hover:from-[#000000]/10 hover:to-[#156b5f]/10 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`,
                                        style: {
                                            transitionDelay: `${400 + idx * 100}ms`
                                        },
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
                                                className: "mb-2 text-xl font-bold text-white transition-colors group-hover:text-[#666666]",
                                                children: feature.title
                                            }, void 0, false, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                                lineNumber: 122,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                                                className: "text-gray-400",
                                                children: feature.description
                                            }, void 0, false, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                                lineNumber: 125,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, idx, true, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                        lineNumber: 113,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                lineNumber: 111,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                        className: "mt-16 text-center",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
                                className: "mb-4 text-2xl font-bold text-white",
                                children: "Ready to order?"
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                lineNumber: 133,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                                className: "mb-8 text-gray-400",
                                children: "Minimum order €10,000 \xb7 100% prepayment \xb7 4-7 weeks delivery"
                            }, void 0, false, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                lineNumber: 136,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                className: "flex flex-wrap justify-center gap-4",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                                        href: "/products",
                                        className: "rounded-lg bg-[#000000] px-8 py-4 text-lg font-semibold text-white transition-all hover:bg-[#156b5f] hover:scale-105 hover:shadow-xl hover:shadow-[#000000]/50",
                                        children: "Browse Catalog"
                                    }, void 0, false, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                        lineNumber: 140,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                                        href: "/terms",
                                        className: "rounded-lg border-2 border-[#000000] px-8 py-4 text-lg font-semibold text-white transition-all hover:bg-[#000000]/10",
                                        children: "View Terms"
                                    }, void 0, false, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                        lineNumber: 146,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                                lineNumber: 139,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                        lineNumber: 132,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx",
        lineNumber: 74,
        columnNumber: 5
    }, this);
}


/***/ }),

/***/ "(ssr)/./components/ui/dropdown-menu.tsx":
/*!*****************************************!*\
  !*** ./components/ui/dropdown-menu.tsx ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DropdownMenu: () => (/* binding */ DropdownMenu),
/* harmony export */   DropdownMenuCheckboxItem: () => (/* binding */ DropdownMenuCheckboxItem),
/* harmony export */   DropdownMenuContent: () => (/* binding */ DropdownMenuContent),
/* harmony export */   DropdownMenuGroup: () => (/* binding */ DropdownMenuGroup),
/* harmony export */   DropdownMenuItem: () => (/* binding */ DropdownMenuItem),
/* harmony export */   DropdownMenuLabel: () => (/* binding */ DropdownMenuLabel),
/* harmony export */   DropdownMenuPortal: () => (/* binding */ DropdownMenuPortal),
/* harmony export */   DropdownMenuRadioGroup: () => (/* binding */ DropdownMenuRadioGroup),
/* harmony export */   DropdownMenuRadioItem: () => (/* binding */ DropdownMenuRadioItem),
/* harmony export */   DropdownMenuSeparator: () => (/* binding */ DropdownMenuSeparator),
/* harmony export */   DropdownMenuShortcut: () => (/* binding */ DropdownMenuShortcut),
/* harmony export */   DropdownMenuSub: () => (/* binding */ DropdownMenuSub),
/* harmony export */   DropdownMenuSubContent: () => (/* binding */ DropdownMenuSubContent),
/* harmony export */   DropdownMenuSubTrigger: () => (/* binding */ DropdownMenuSubTrigger),
/* harmony export */   DropdownMenuTrigger: () => (/* binding */ DropdownMenuTrigger)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @radix-ui/react-dropdown-menu */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/@radix-ui/react-dropdown-menu/dist/index.mjs");
/* harmony import */ var _barrel_optimize_names_Check_ChevronRight_Circle_lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=Check,ChevronRight,Circle!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/chevron-right.js");
/* harmony import */ var _barrel_optimize_names_Check_ChevronRight_Circle_lucide_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! __barrel_optimize__?names=Check,ChevronRight,Circle!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/check.js");
/* harmony import */ var _barrel_optimize_names_Check_ChevronRight_Circle_lucide_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! __barrel_optimize__?names=Check,ChevronRight,Circle!=!lucide-react */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/lucide-react/dist/esm/icons/circle.js");
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/lib/utils */ "(ssr)/./lib/utils.ts");
/* __next_internal_client_entry_do_not_use__ DropdownMenu,DropdownMenuTrigger,DropdownMenuContent,DropdownMenuItem,DropdownMenuCheckboxItem,DropdownMenuRadioItem,DropdownMenuLabel,DropdownMenuSeparator,DropdownMenuShortcut,DropdownMenuGroup,DropdownMenuPortal,DropdownMenuSub,DropdownMenuSubContent,DropdownMenuSubTrigger,DropdownMenuRadioGroup auto */ 




const DropdownMenu = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Root;
const DropdownMenuTrigger = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Trigger;
const DropdownMenuGroup = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Group;
const DropdownMenuPortal = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Portal;
const DropdownMenuSub = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Sub;
const DropdownMenuRadioGroup = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.RadioGroup;
const DropdownMenuSubTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, inset, children, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.SubTrigger, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent", inset && "pl-8", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Check_ChevronRight_Circle_lucide_react__WEBPACK_IMPORTED_MODULE_4__["default"], {
                className: "ml-auto h-4 w-4"
            }, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
                lineNumber: 37,
                columnNumber: 5
            }, undefined)
        ]
    }, void 0, true, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
        lineNumber: 27,
        columnNumber: 3
    }, undefined));
DropdownMenuSubTrigger.displayName = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.SubTrigger.displayName;
const DropdownMenuSubContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.SubContent, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", className),
        ...props
    }, void 0, false, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
        lineNumber: 47,
        columnNumber: 3
    }, undefined));
DropdownMenuSubContent.displayName = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.SubContent.displayName;
const DropdownMenuContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, sideOffset = 4, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Portal, {
        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Content, {
            ref: ref,
            sideOffset: sideOffset,
            className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", className),
            ...props
        }, void 0, false, {
            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
            lineNumber: 64,
            columnNumber: 5
        }, undefined)
    }, void 0, false, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
        lineNumber: 63,
        columnNumber: 3
    }, undefined));
DropdownMenuContent.displayName = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Content.displayName;
const DropdownMenuItem = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, inset, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Item, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", inset && "pl-8", className),
        ...props
    }, void 0, false, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
        lineNumber: 83,
        columnNumber: 3
    }, undefined));
DropdownMenuItem.displayName = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Item.displayName;
const DropdownMenuCheckboxItem = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, children, checked, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.CheckboxItem, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        checked: checked,
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.ItemIndicator, {
                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Check_ChevronRight_Circle_lucide_react__WEBPACK_IMPORTED_MODULE_5__["default"], {
                        className: "h-4 w-4"
                    }, void 0, false, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
                        lineNumber: 110,
                        columnNumber: 9
                    }, undefined)
                }, void 0, false, {
                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
                    lineNumber: 109,
                    columnNumber: 7
                }, undefined)
            }, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
                lineNumber: 108,
                columnNumber: 5
            }, undefined),
            children
        ]
    }, void 0, true, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
        lineNumber: 99,
        columnNumber: 3
    }, undefined));
DropdownMenuCheckboxItem.displayName = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.CheckboxItem.displayName;
const DropdownMenuRadioItem = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.RadioItem, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.ItemIndicator, {
                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Check_ChevronRight_Circle_lucide_react__WEBPACK_IMPORTED_MODULE_6__["default"], {
                        className: "h-2 w-2 fill-current"
                    }, void 0, false, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
                        lineNumber: 133,
                        columnNumber: 9
                    }, undefined)
                }, void 0, false, {
                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
                    lineNumber: 132,
                    columnNumber: 7
                }, undefined)
            }, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
                lineNumber: 131,
                columnNumber: 5
            }, undefined),
            children
        ]
    }, void 0, true, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
        lineNumber: 123,
        columnNumber: 3
    }, undefined));
DropdownMenuRadioItem.displayName = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.RadioItem.displayName;
const DropdownMenuLabel = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, inset, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Label, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
        ...props
    }, void 0, false, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
        lineNumber: 147,
        columnNumber: 3
    }, undefined));
DropdownMenuLabel.displayName = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Label.displayName;
const DropdownMenuSeparator = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Separator, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("-mx-1 my-1 h-px bg-muted", className),
        ...props
    }, void 0, false, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
        lineNumber: 163,
        columnNumber: 3
    }, undefined));
DropdownMenuSeparator.displayName = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Separator.displayName;
const DropdownMenuShortcut = ({ className, ...props })=>{
    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("ml-auto text-xs tracking-widest opacity-60", className),
        ...props
    }, void 0, false, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/ui/dropdown-menu.tsx",
        lineNumber: 176,
        columnNumber: 5
    }, undefined);
};
DropdownMenuShortcut.displayName = "DropdownMenuShortcut";



/***/ }),

/***/ "(ssr)/./lib/utils.ts":
/*!**********************!*\
  !*** ./lib/utils.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cn: () => (/* binding */ cn),
/* harmony export */   formatDuration: () => (/* binding */ formatDuration)
/* harmony export */ });
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! clsx */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/clsx/dist/clsx.mjs");
/* harmony import */ var tailwind_merge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tailwind-merge */ "(ssr)/../../../../opt/hostedapp/node/root/app/node_modules/tailwind-merge/dist/bundle-mjs.mjs");


function cn(...inputs) {
    return (0,tailwind_merge__WEBPACK_IMPORTED_MODULE_1__.twMerge)((0,clsx__WEBPACK_IMPORTED_MODULE_0__.clsx)(inputs));
}
function formatDuration(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor(seconds % 3600 / 60);
    const remainingSeconds = seconds % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
}


/***/ }),

/***/ "(rsc)/./app/globals.css":
/*!*************************!*\
  !*** ./app/globals.css ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("6929614223ea");
if (false) {}


/***/ }),

/***/ "(rsc)/./app/layout.tsx":
/*!************************!*\
  !*** ./app/layout.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout),
/* harmony export */   dynamic: () => (/* binding */ dynamic),
/* harmony export */   metadata: () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/font/google/target.css?{"path":"app/layout.tsx","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"} */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/font/google/target.css?{\"path\":\"app/layout.tsx\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}");
/* harmony import */ var next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals.css */ "(rsc)/./app/globals.css");
/* harmony import */ var _components_providers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/providers */ "(rsc)/./components/providers.tsx");




const dynamic = "force-dynamic";
const metadata = {
    title: "ADORIS INVEST GROUP - Medical Laboratory Equipment & Supplies",
    description: "Professional B2B medical laboratory equipment and supplies. High-quality analyzers, reagents, and laboratory consumables from leading manufacturers.",
    metadataBase: new URL(process.env.NEXTAUTH_URL || "http://localhost:3000"),
    icons: {
        icon: "/favicon.ico",
        shortcut: "/favicon.ico",
        apple: "/logo.png"
    },
    openGraph: {
        title: "ADORIS INVEST GROUP - Medical Laboratory Equipment & Supplies",
        description: "Professional B2B medical laboratory equipment and supplies",
        images: [
            "/og-image.png"
        ]
    }
};
function RootLayout({ children }) {
    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("html", {
        lang: "en",
        suppressHydrationWarning: true,
        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("body", {
            className: (next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_3___default().className),
            suppressHydrationWarning: true,
            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_providers__WEBPACK_IMPORTED_MODULE_2__.Providers, {
                children: children
            }, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/app/layout.tsx",
                lineNumber: 36,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/app/layout.tsx",
            lineNumber: 35,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/app/layout.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}


/***/ }),

/***/ "(rsc)/./app/page.tsx":
/*!**********************!*\
  !*** ./app/page.tsx ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ HomePage),
/* harmony export */   dynamic: () => (/* binding */ dynamic)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/header */ "(rsc)/./components/header.tsx");
/* harmony import */ var _components_footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/footer */ "(rsc)/./components/footer.tsx");
/* harmony import */ var _components_hero_section__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/hero-section */ "(rsc)/./components/hero-section.tsx");
/* harmony import */ var _components_featured_products__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/featured-products */ "(rsc)/./components/featured-products.tsx");
/* harmony import */ var _components_category_showcase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/category-showcase */ "(rsc)/./components/category-showcase.tsx");
/* harmony import */ var _components_stats_section__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/stats-section */ "(rsc)/./components/stats-section.tsx");
/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/lib/db */ "(rsc)/./lib/db.ts");








const dynamic = "force-dynamic";
async function HomePage() {
    // Fetch featured products
    const featuredProducts = await _lib_db__WEBPACK_IMPORTED_MODULE_7__.prisma.product.findMany({
        where: {
            featured: true
        },
        include: {
            category: true,
            manufacturer: true
        },
        take: 8,
        orderBy: {
            createdAt: "desc"
        }
    });
    // Fetch products by category for showcase
    const categories = await _lib_db__WEBPACK_IMPORTED_MODULE_7__.prisma.category.findMany({
        include: {
            products: {
                take: 6,
                include: {
                    manufacturer: true
                }
            }
        }
    });
    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_header__WEBPACK_IMPORTED_MODULE_1__.Header, {}, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/app/page.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("main", {
                className: "min-h-screen bg-gradient-to-b from-black via-gray-900 to-black",
                children: [
                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_hero_section__WEBPACK_IMPORTED_MODULE_3__.HeroSection, {}, void 0, false, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/app/page.tsx",
                        lineNumber: 39,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_featured_products__WEBPACK_IMPORTED_MODULE_4__.FeaturedProducts, {
                        products: featuredProducts
                    }, void 0, false, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/app/page.tsx",
                        lineNumber: 40,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_category_showcase__WEBPACK_IMPORTED_MODULE_5__.CategoryShowcase, {
                        categories: categories
                    }, void 0, false, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/app/page.tsx",
                        lineNumber: 41,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_stats_section__WEBPACK_IMPORTED_MODULE_6__.StatsSection, {}, void 0, false, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/app/page.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/app/page.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_footer__WEBPACK_IMPORTED_MODULE_2__.Footer, {}, void 0, false, {
                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/app/page.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}


/***/ }),

/***/ "(rsc)/./components/category-showcase.tsx":
/*!******************************************!*\
  !*** ./components/category-showcase.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CategoryShowcase: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/build/webpack/loaders/next-flight-loader/module-proxy */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js");


const e0 = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/ubuntu/ivdgroup_mvp/nextjs_space/components/category-showcase.tsx#CategoryShowcase`);


/***/ }),

/***/ "(rsc)/./components/featured-products.tsx":
/*!******************************************!*\
  !*** ./components/featured-products.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FeaturedProducts: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/build/webpack/loaders/next-flight-loader/module-proxy */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js");


const e0 = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/ubuntu/ivdgroup_mvp/nextjs_space/components/featured-products.tsx#FeaturedProducts`);


/***/ }),

/***/ "(rsc)/./components/footer.tsx":
/*!*******************************!*\
  !*** ./components/footer.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Footer: () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/api/link.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/api/image.js");



function Footer() {
    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("footer", {
        className: "bg-black text-white mt-12 sm:mt-20",
        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "container mx-auto px-4 sm:px-6 py-8 sm:py-12",
            children: [
                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                                    className: "relative w-28 h-9 sm:w-32 sm:h-10 mb-3 sm:mb-4",
                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                        src: "/logo.png",
                                        alt: "ADORIS INVEST GROUP",
                                        fill: true,
                                        className: "object-contain"
                                    }, void 0, false, {
                                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                        lineNumber: 12,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                    lineNumber: 11,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                                    className: "text-neutral-300 text-xs sm:text-sm",
                                    children: "Professional B2B medical laboratory equipment and supplies from leading manufacturers worldwide."
                                }, void 0, false, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                    lineNumber: 19,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                            lineNumber: 10,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
                                    className: "font-bold text-base sm:text-lg mb-3 sm:mb-4",
                                    children: "Quick Links"
                                }, void 0, false, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                    lineNumber: 27,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                                    className: "space-y-1.5 sm:space-y-2",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                                href: "/",
                                                className: "text-neutral-300 hover:text-[#cccccc] transition-colors text-xs sm:text-sm",
                                                children: "Products"
                                            }, void 0, false, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                                lineNumber: 30,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                            lineNumber: 29,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                                href: "/bulk-order",
                                                className: "text-neutral-300 hover:text-[#cccccc] transition-colors text-xs sm:text-sm",
                                                children: "Bulk Order"
                                            }, void 0, false, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                                lineNumber: 38,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                            lineNumber: 37,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                                href: "/exhibitions",
                                                className: "text-neutral-300 hover:text-[#cccccc] transition-colors text-xs sm:text-sm",
                                                children: "Exhibitions"
                                            }, void 0, false, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                                lineNumber: 46,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                            lineNumber: 45,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                                href: "/terms",
                                                className: "text-neutral-300 hover:text-[#cccccc] transition-colors text-xs sm:text-sm",
                                                children: "Terms & Conditions"
                                            }, void 0, false, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                                lineNumber: 54,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                            lineNumber: 53,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                                href: "/cart",
                                                className: "text-neutral-300 hover:text-[#cccccc] transition-colors text-xs sm:text-sm",
                                                children: "Shopping Cart"
                                            }, void 0, false, {
                                                fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                                lineNumber: 62,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                            lineNumber: 61,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                    lineNumber: 28,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                            lineNumber: 26,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
                                    className: "font-bold text-base sm:text-lg mb-3 sm:mb-4",
                                    children: "Contact Us"
                                }, void 0, false, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                    lineNumber: 74,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                                    className: "space-y-1.5 sm:space-y-2 text-xs sm:text-sm",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                            className: "text-neutral-300",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                    className: "font-semibold",
                                                    children: "Email:"
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                                    lineNumber: 77,
                                                    columnNumber: 17
                                                }, this),
                                                " ceo@adorisgroup.com"
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                            lineNumber: 76,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                            className: "text-neutral-300",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                    className: "font-semibold",
                                                    children: "Phone:"
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                                    lineNumber: 80,
                                                    columnNumber: 17
                                                }, this),
                                                " +48 881 049 959"
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                            lineNumber: 79,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                            className: "text-neutral-300 hidden sm:block",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                    className: "font-semibold",
                                                    children: "Website:"
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                                    lineNumber: 83,
                                                    columnNumber: 17
                                                }, this),
                                                " www.adorisgroup.com"
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                            lineNumber: 82,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                    lineNumber: 75,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                            lineNumber: 73,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
                                    className: "font-bold text-base sm:text-lg mb-3 sm:mb-4",
                                    children: "Company Info"
                                }, void 0, false, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                    lineNumber: 90,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                                    className: "space-y-1.5 sm:space-y-2 text-xs sm:text-sm text-neutral-300",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                            children: "ADORIS INVEST GROUP O\xdc"
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                            lineNumber: 92,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                            children: "Ruunaoja tn 3-36"
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                            lineNumber: 93,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                            children: "11415 Tallinn, Estonia"
                                        }, void 0, false, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                            lineNumber: 94,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                            className: "pt-2",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                    className: "font-semibold",
                                                    children: "Reg. Code:"
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                                    lineNumber: 96,
                                                    columnNumber: 17
                                                }, this),
                                                " 12825289"
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                            lineNumber: 95,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                                                    className: "font-semibold",
                                                    children: "VAT EE:"
                                                }, void 0, false, {
                                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                                    lineNumber: 99,
                                                    columnNumber: 17
                                                }, this),
                                                " EE102079353"
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                            lineNumber: 98,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                                    lineNumber: 91,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                            lineNumber: 89,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                    lineNumber: 8,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                    className: "border-t border-neutral-700 mt-6 sm:mt-8 pt-6 sm:pt-8 text-center text-xs sm:text-sm text-neutral-400",
                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                        children: [
                            "\xa9 ",
                            new Date()?.getFullYear() || 2025,
                            " ADORIS INVEST GROUP O\xdc. All rights reserved."
                        ]
                    }, void 0, true, {
                        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                        lineNumber: 106,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
                    lineNumber: 105,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
            lineNumber: 7,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "/home/ubuntu/ivdgroup_mvp/nextjs_space/components/footer.tsx",
        lineNumber: 6,
        columnNumber: 5
    }, this);
}


/***/ }),

/***/ "(rsc)/./components/header.tsx":
/*!*******************************!*\
  !*** ./components/header.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Header: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/build/webpack/loaders/next-flight-loader/module-proxy */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js");


const e0 = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/ubuntu/ivdgroup_mvp/nextjs_space/components/header.tsx#Header`);


/***/ }),

/***/ "(rsc)/./components/hero-section.tsx":
/*!*************************************!*\
  !*** ./components/hero-section.tsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HeroSection: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/build/webpack/loaders/next-flight-loader/module-proxy */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js");


const e0 = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/ubuntu/ivdgroup_mvp/nextjs_space/components/hero-section.tsx#HeroSection`);


/***/ }),

/***/ "(rsc)/./components/providers.tsx":
/*!**********************************!*\
  !*** ./components/providers.tsx ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Providers: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/build/webpack/loaders/next-flight-loader/module-proxy */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js");


const e0 = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/ubuntu/ivdgroup_mvp/nextjs_space/components/providers.tsx#Providers`);


/***/ }),

/***/ "(rsc)/./components/stats-section.tsx":
/*!**************************************!*\
  !*** ./components/stats-section.tsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StatsSection: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/build/webpack/loaders/next-flight-loader/module-proxy */ "(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js");


const e0 = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/ubuntu/ivdgroup_mvp/nextjs_space/components/stats-section.tsx#StatsSection`);


/***/ }),

/***/ "(rsc)/./lib/db.ts":
/*!*******************!*\
  !*** ./lib/db.ts ***!
  \*******************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   prisma: () => (/* binding */ prisma)
/* harmony export */ });
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @prisma/client */ "@prisma/client");
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);

const globalForPrisma = globalThis;
const prisma = globalForPrisma.prisma ?? new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient();
if (true) globalForPrisma.prisma = prisma;


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@babel","vendor-chunks/@radix-ui","vendor-chunks/lucide-react","vendor-chunks/react-remove-scroll","vendor-chunks/@swc","vendor-chunks/next-auth","vendor-chunks/@floating-ui","vendor-chunks/react-style-singleton","vendor-chunks/react-remove-scroll-bar","vendor-chunks/use-callback-ref","vendor-chunks/use-sidecar","vendor-chunks/tslib","vendor-chunks/tailwind-merge","vendor-chunks/react-hot-toast","vendor-chunks/goober","vendor-chunks/clsx","vendor-chunks/get-nonce","vendor-chunks/aria-hidden"], () => (__webpack_exec__("(rsc)/../../../../opt/hostedapp/node/root/app/node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fpage&page=%2Fpage&appPaths=%2Fpage&pagePath=private-next-app-dir%2Fpage.tsx&appDir=%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fhome%2Fubuntu%2Fivdgroup_mvp%2Fnextjs_space&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();